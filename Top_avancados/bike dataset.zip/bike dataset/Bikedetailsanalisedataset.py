# 1° parte — Leitura do dataset

import csv

dataset = "BIKE_DETAILS.csv"
dados = []

with open(dataset, 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    for registro in leitor:
        dados.append(registro)

print("Nome do dataset: BIKE_DETAILS.csv")
print(f"Quantidade de registros: {len(dados)}")
print(f"Colunas: {list(dados[0].keys())}")

print("\nPrimeiros 5 registros:")
for i in range(min(5, len(dados))):
    print(f"{i+1}: {dados[i]}")


# 2° parte — Estatísticas

colunas = ['selling_price', 'km_driven']

def calcular_estatisticas(lista):
    if len(lista) == 0:
        return None, None, None, 0
    
    minimo = min(lista)
    maximo = max(lista)
    media = sum(lista) / len(lista)
    contagem = len(lista)
    
    return minimo, maximo, media, contagem


for coluna in colunas:
    valores = []
    
    for registro in dados:
        valor = registro.get(coluna, '').strip()
        
        if valor != '':
            try:
                valores.append(float(valor))
            except:
                continue
    
    minimo, maximo, media, contagem = calcular_estatisticas(valores)
    
    print(f"\nEstatísticas da coluna: {coluna}")
    print(f"Quantidade: {contagem}")
    
    if contagem > 0:
        print(f"Mínimo: {minimo}")
        print(f"Máximo: {maximo}")
        print(f"Média: {media:.2f}")


# 3° parte — Filtros

# Filtro 1 — Tipo de dono (interativo)
usuario = input("\nDigite o tipo de dono (1st owner / 2nd owner / 3rd owner): ")

filtro1 = []

for linha in dados:
    if linha.get('owner') == usuario:
        filtro1.append(linha)

print("\nFiltro: Tipo de dono =", usuario)
print("Quantidade:", len(filtro1))
print("Resultados:", filtro1[:10])


# Filtro 2 — KM até 20000
filtro2 = []

for linha in dados:
    valor = linha.get('km_driven', '').strip()
    
    if valor != '':
        try:
            if float(valor) <= 20000:
                filtro2.append(linha)
        except:
            continue

print("\nFiltro: KM até 20000")
print("Quantidade:", len(filtro2))
print("Resultados:", filtro2[:10])


# Filtro 3 — Preço acima de 50000
filtro3 = []

for linha in dados:
    valor = linha.get('selling_price', '').strip()
    
    if valor != '':
        try:
            if float(valor) > 50000:
                filtro3.append(linha)
        except:
            continue

print("\nFiltro: Preço acima de 50000")
print("Quantidade:", len(filtro3))
print("Resultados:", filtro3[:10])


# 4° parte — Relatório TXT

with open('bikes.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write("Nome do dataset: BIKE_DETAILS.csv\n")
    arquivo.write("Descrição: Dataset com motos usadas à venda.\n")
    arquivo.write(f"Registros: {len(dados)}\n")
    arquivo.write(f"Colunas: {list(dados[0].keys())}\n\n")
    
    arquivo.write("Estatísticas:\n")
    
    for coluna in colunas:
        valores = []
        
        for registro in dados:
            valor = registro.get(coluna, '').strip()
            
            if valor != '':
                try:
                    valores.append(float(valor))
                except:
                    continue
        
        minimo, maximo, media, contagem = calcular_estatisticas(valores)
        
        arquivo.write(f"\nColuna: {coluna}\n")
        arquivo.write(f"Quantidade: {contagem}\n")
        
        if contagem > 0:
            arquivo.write(f"Mínimo: {minimo}\n")
            arquivo.write(f"Máximo: {maximo}\n")
            arquivo.write(f"Média: {media:.2f}\n")
    
    arquivo.write("\nFiltros:\n")
    arquivo.write(f"Tipo de dono ({usuario}): {len(filtro1)} resultados\n")
    arquivo.write(f"KM até 20000: {len(filtro2)} resultados\n")
    arquivo.write(f"Preço acima de 50000: {len(filtro3)} resultados\n")
    
    arquivo.write("\nConclusão:\n")
    arquivo.write("- Há grande variação de preços no dataset.\n")
    arquivo.write("- Existem muitas motos com baixa quilometragem.\n")
    arquivo.write("- O tipo de dono influencia na quantidade de motos.\n")


# leitura do arquivo
with open('bikes.txt', 'r', encoding='utf-8') as arquivo:
    print("\nRELATÓRIO:\n")
    print(arquivo.read())
